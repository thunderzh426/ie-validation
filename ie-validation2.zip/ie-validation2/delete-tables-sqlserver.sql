delete from crf;
dbcc checkident ('crf', reseed, 0);
delete from crf_element;

delete from crf_section;
dbcc checkident ('crf_section', reseed, 0);

delete from element;
dbcc checkident ('element', reseed, 0);

delete from element_value;

delete from frame;
dbcc checkident ('frame', reseed, 0);


#project only
delete from app_NLP_0816.crf_project;
dbcc checkident ('app_NLP_0816.crf_project', reseed, 0);

delete from app_NLP_0816.crf_project_frame_instance;

delete from app_NLP_0816.frame_instance;
dbcc checkident ('app_NLP_0816.frame_instance', reseed, 0);

delete from app_NLP_0816.frame_instance_annotation;

delete from app_NLP_0816.frame_instance_document;


# data only
delete from frame_instance_data;

delete from frame_instance_document_history;

delete from frame_instance_element_repeat;

delete from frame_instance_section_repeat;

delete from annotation;




delete from frame_slot;

delete from provenance;
dbcc checkident ('provenance', reseed, 0);

delete from slot;
dbcc checkident ('slot', reseed, 0);

delete from value;
dbcc checkident ('value', reseed, 0);