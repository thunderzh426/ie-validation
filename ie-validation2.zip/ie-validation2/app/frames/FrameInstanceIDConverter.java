package frames;

import java.sql.*;
import java.util.*;

import utils.db.DBConnection;

public class FrameInstanceIDConverter
{
	
	private Connection conn;
	private PreparedStatement pstmt;
	private PreparedStatement pstmt2;
	private PreparedStatement pstmt3;
	
	public FrameInstanceIDConverter()
	{
	}
	
	public void convert(String user, String password, String frameInstanceTableName1, String frameInstanceTableName2, String frameInstanceDocTableName1, String frameInstanceDocTableName2, String crossWalkTableName)
	{
		try {
			conn = DBConnection.dbConnection(user, password, "10.9.94.203", "validator", "mysql");
			pstmt = conn.prepareStatement("select document_namespace, document_table, document_id from " + frameInstanceDocTableName2 + " where frame_instance_id = ?");
			pstmt2 = conn.prepareStatement("select frame_instance_id from " + frameInstanceDocTableName1 + " where document_namespace = ? and document_table = ? and document_id = ?");
			pstmt3 = conn.prepareStatement("insert into " + crossWalkTableName + " (frame_instance_id, frame_instance_id_new) values (?,?)");
			
			//create crosswalk table
			Statement stmt = conn.createStatement();
			stmt.execute("create table " + crossWalkTableName + " (frame_instance_id int, frame_instance_id_new int)");
			
			List<Integer> frameInstanceIDList2 = new ArrayList<Integer>();
			
			ResultSet rs = stmt.executeQuery("select frame_instance_id from " + frameInstanceTableName2);
			while (rs.next()) {
				int fID = rs.getInt(1);
				frameInstanceIDList2.add(fID);
			}
			
			rs.close();
			
			for (int fID2 : frameInstanceIDList2) {
				pstmt.setInt(1, fID2);
				rs = pstmt.executeQuery();
				
				pstmt3.setInt(2, fID2);
				
				while (rs.next()) {
					String docNamespace = rs.getString(1);
					String docTable = rs.getString(2);
					int docID = rs.getInt(3);
					
					List<Integer> frameInstanceIDList1 = getFrameInstanceIDs(docNamespace, docTable, docID);
					for (int fID1 : frameInstanceIDList1) {
						pstmt3.setInt(1, fID1);
					}
				}
			}
			
			
			//update frameInstanceIDs in other tables
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	private List<Integer> getFrameInstanceIDs(String docNamespace, String docTable, int docID) throws SQLException
	{
		List<Integer> frameInstanceIDList = new ArrayList<Integer>();
		pstmt2.setString(1, docNamespace);
		pstmt2.setString(2, docTable);
		pstmt2.setInt(3, docID);
		ResultSet rs = pstmt2.executeQuery();
		
		while (rs.next()) {
			int fID = rs.getInt(1);
			frameInstanceIDList.add(fID);
		}
		
		return frameInstanceIDList;
	}

}
