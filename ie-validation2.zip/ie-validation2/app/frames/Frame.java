package frames;

import java.util.*;

import com.google.gson.Gson;

public class Frame
{
	protected String id;
	protected Map<String, Object> slotMap;
	protected static Gson gson;
	
	public Frame()
	{
		if (gson == null)
			gson = new Gson();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Object get(String slot)
	{
		List<String> slotList = new ArrayList<String>();
		slotList = gson.fromJson(slot, slotList.getClass());
				
		return get(slotList);
	}
	
	public Object get(List<String> slotList)
	{
		Object retVal = null;
		
		Map<String, Object> map = this.slotMap;
		for (String slotStr: slotList) {
			Object slotVal = map.get(slotStr);
			if (slotVal instanceof Map) {
				map = (Map<String, Object>) slotVal;
			}
			else
				retVal = slotVal;
		}
				
		return retVal;
	}

	public void put(String slot, Object value) {
		slotMap.put(slot, value);
	}
}
