package frames;

import java.util.*;

public class ElementBean
{
	private int sectionID;
	private int repeat;
	private int primaryKey;
	private List<String> annotTypeList;
	
	public ElementBean()
	{
	}

	public int getSectionID() {
		return sectionID;
	}

	public void setSectionID(int sectionID) {
		this.sectionID = sectionID;
	}

	public int getRepeat() {
		return repeat;
	}

	public void setRepeat(int repeat) {
		this.repeat = repeat;
	}

	public int getPrimaryKey() {
		return primaryKey;
	}

	public void setPrimaryKey(int primaryKey) {
		this.primaryKey = primaryKey;
	}

	public List<String> getAnnotTypeList() {
		return annotTypeList;
	}

	public void setAnnotTypeList(List<String> annotTypeList) {
		this.annotTypeList = annotTypeList;
	}
	
	
}
