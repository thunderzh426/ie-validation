package frames;

import java.util.*;

import com.google.gson.Gson;

abstract public class DecisionTreeNode
{
	protected List<DecisionTreeNode> children;
	protected String outputID;
	protected String className;
	protected List<String> inputList;
	protected static Gson gson;
	
	public DecisionTreeNode()
	{
		children = new ArrayList<DecisionTreeNode>();
		if (gson == null)
			gson = new Gson();
	}
	
	public DecisionTreeNode(String outputID, String className)
	{
		this();
		this.outputID = outputID;
		this.className = className;
	}
	
	public String getOutputID()
	{
		return outputID;
	}
	
	public void setOutputID(String outputID)
	{
		this.outputID = outputID;
	}

	public List<DecisionTreeNode> getChildren()
	{
		return children;
	}
	
	public void addChild(DecisionTreeNode node)
	{
		children.add(node);
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}
	
	abstract boolean match(Map<String, Frame> frames) throws DecisionTreeInvalidTypeException;

	public List<String> getInputList() {
		return inputList;
	}

	public void setInputList(List<String> inputList) {
		this.inputList = inputList;
	}
	
	public void addInput(String input)
	{
		inputList.add(input);
	}
	
	protected Object getSlot(String slot)
	{
		List<String> slotList = new ArrayList<String>();
		slotList = (List<String>) gson.fromJson(slot, slotList.getClass());
		
		return null;
	}
}
