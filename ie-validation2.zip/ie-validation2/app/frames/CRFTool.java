package frames;

public class CRFTool
{

	public CRFTool()
	{
	}
	
	public void deleteProject(int projID)
	{
		
	}
	
	public void deleteCRF(int crfID)
	{
		
	}
}
