package frames;

import java.sql.*;
import java.util.*;
import java.io.*;

import utils.db.DBConnection;

public class FrameFiller
{

	private Connection conn;
	private int projectID;
	private int crfID;
	private String annotTypeClause;
	private String docNamespace;
	private String docTable;
	
	private PreparedStatement pstmtGetAnnots;
	private PreparedStatement pstmtElemSlot;
	private PreparedStatement pstmtInsertData;
	
	public FrameFiller()
	{
	}
	
	public void init(String user, String password, String host, String dbName, String dbType)
	{
		try {
			/*
			Properties props = new Properties();
			props.load(new FileReader(config));
			
			String host = props.getProperty("host");
			String dbName = props.getProperty("dbName");
			String dbType = props.getProperty("dbType");
			*/
			
			conn = DBConnection.dbConnection(user, password, host, dbName, dbType);
			
			pstmtGetAnnots = conn.prepareStatement("select annotation_type, start, end from annotation where document_namespace = ? and document_table = ? and document_id = ? "
				+ "and provenance = 'msa-ie' and annotation_type in " + annotTypeClause);
			
			pstmtElemSlot = conn.prepareStatement("select a.element_id, b.slot_id from element_value a, slot b, value c "
				+ "where b.annotation_type = ? and b.slot_id = c.slot_id and c.value_id = a.value_id");
			
			pstmtInsertData = conn.prepareStatement("insert into frame_instance_data (frame_instance_id, slot_id, value, section_slot_number, element_slot_number, document_namespace, document_table, document_id, annotation_id, annotation_namespace, element_id) "
				+ "values (?,?,?,?,?,?,?,?,?,?,?)");
			
			//Map<String, List<AnnotationBean>> annotMap = getAnnotMap();
			
			
			
			//conn.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void close()
	{
		try {
			conn.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void fillFrames(int projID)
	{
		try {
			List<String> annotTypeList = getAnnotTypeList(projID);
			StringBuilder strBlder = new StringBuilder();
			
			for (String annotType : annotTypeList) {
				if (strBlder.length() > 0)
					strBlder.append(", ");
				
				strBlder.append("'" + annotType + "'");
			}
			
			strBlder.insert(0, "(");
			strBlder.append(")");
			
			annotTypeClause = strBlder.toString();
			
			System.out.println(annotTypeClause);
			
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select frame_instance_id from crf_project_frame_instance where crf_project_id = " + projID);
			while (rs.next()) {
				int frameInstanceID = rs.getInt(1);
				fillFrame(projID, frameInstanceID);
			}
			
			stmt.close();
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	private void fillFrame(int projID, int frameInstanceID) throws SQLException
	{		
		pstmtInsertData.setInt(1, frameInstanceID);
		pstmtInsertData.setInt(4, 0);
		pstmtInsertData.setInt(5, 0);
		pstmtInsertData.setString(6, "validator");
		pstmtInsertData.setString(7, "documents");
		pstmtInsertData.setString(10, "test");
		
		
		Statement stmt = conn.createStatement();
		
		long docID = getDocumentID(frameInstanceID);
		
		System.out.println("select id, annotation_type, start, end, value from annotation where document_id = " + docID + " and provenance = 'msa-ie' and annotation_type in " + annotTypeClause);
		ResultSet rs = stmt.executeQuery("select id, annotation_type, start, end, value from annotation where document_id = " + docID 
			+ " and provenance = 'msa-ie' and annotation_type in " + annotTypeClause);
		while (rs.next()) {
			int annotID = rs.getInt(1);
			String annotType = rs.getString(2);
			int start = rs.getInt(3);
			int end = rs.getInt(4);
			String value = rs.getString(5);
			
			int[] elemSlotVals = getElementAndSlot(projID, annotType);
			
			pstmtInsertData.setInt(2, elemSlotVals[1]);
			pstmtInsertData.setString(3, value);
			pstmtInsertData.setLong(8, docID);
			pstmtInsertData.setInt(9, annotID);
			pstmtInsertData.setInt(11, elemSlotVals[0]);
			pstmtInsertData.execute();
		}
		
		stmt.close();
	}
	
	private int[] getElementAndSlot(int projID, String annotType) throws SQLException
	{
		int[] vals = new int[2];
		Statement stmt = conn.createStatement();
		pstmtElemSlot.setString(1, annotType);
		ResultSet rs = pstmtElemSlot.executeQuery();
		if (rs.next()) {
			vals[0] = rs.getInt(1);
			vals[1] = rs.getInt(2);
		}
		
		stmt.close();
		
		return vals;
	}
	
	private long getDocumentID(int frameInstanceID) throws SQLException
	{
		long docID = -1;
		
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery("select document_id from frame_instance_document where frame_instance_id = " + frameInstanceID);
		if (rs.next()) {
			docID = rs.getLong(1);
		}
		stmt.close();
		return docID;
	}
	
	/*
	private Map<String, List<AnnotationBean>> getAnnotMap()
	{
		
	}
	
	private void fillSection(int frameInstanceID, int sectionID)
	{
		List<ElementBean> elementList = getElementsInSection(sectionID);
		List<ElementBean> pkElementList = getPKElementsInSection(sectionID);
		
		
		for (Long docID : docIDList) {
			List<AnnotationBean> pkAnnotList = getAnnotations(docID);
			
		}
		
	}
	*/
	
	private List<ElementBean> getElementsInSection(int sectionID)
	{
		List<ElementBean> elementList = new ArrayList<ElementBean>();
		
		return elementList;
	}
	
	private List<ElementBean> getPKElementsInSection(int sectionID)
	{
		List<ElementBean> pkElementList = new ArrayList<ElementBean>();
		
		return pkElementList;
	}
	
	private List<String> getAnnotTypeList(int projID) throws SQLException
	{
		List<String> annotTypeList = new ArrayList<String>();
		
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery("select d.annotation_type from crf_project a, crf_element b, element_value c, slot d, value e "
			+ "where a.crf_id = b.crf_id and b.element_id = c.element_id and e.slot_id = d.slot_id and e.value_id = c.value_id and a.crf_project_id = " + projID);
		
		while (rs.next()) {
			annotTypeList.add(rs.getString(1));
		}
		
		stmt.close();
		
		return annotTypeList;
	}
	
	private List<AnnotationBean> getAnnotations(long docID) throws SQLException
	{
		List<AnnotationBean> annotList = new ArrayList<AnnotationBean>();
		
		Statement stmt = conn.createStatement();
		pstmtGetAnnots.setString(1, docNamespace);
		pstmtGetAnnots.setString(2, docTable);
		pstmtGetAnnots.setLong(3, docID);
		ResultSet rs = pstmtGetAnnots.executeQuery();
		while (rs.next()) {
			String annotType = rs.getString(1);
			int start = rs.getInt(2);
			int end = rs.getInt(3);
			
			AnnotationBean annot = new AnnotationBean(annotType, start, end);
			annotList.add(annot);
		}
		
		stmt.close();
		
		return annotList;
	}
	
	public static void main(String[] args)
	{
		FrameFiller frameFiller = new FrameFiller();
		frameFiller.init("fmeng", "fmeng", "localhost", "validator", "mysql");
		frameFiller.fillFrames(1);
		frameFiller.close();
	}
}
