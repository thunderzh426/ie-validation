package frames;

import java.util.*;

import com.google.gson.Gson;

public class DecisionTree
{
	private DecisionTreeNode root;
	private List<String> inputList;
	private static Gson gson;
	
	public DecisionTree()
	{
		if (gson == null)
			gson = new Gson();
	}
	
	public DecisionTreeNode getRoot()
	{
		return root;
	}
	
	public void setRoot(DecisionTreeNode root)
	{
		this.root = root;
	}
	
	public void setInputList(List<String> inputList)
	{
		this.inputList = inputList;
	}
	
	public void walkTree(Map<String, Frame> frames) throws DecisionTreeInvalidTypeException
	{
		try {
			List<Map<String, String>> inputMapList = new ArrayList<Map<String, String>>();
			//inputMapList = (List<Map<String, String>>) gson.fromJson(json, classOfT)
			
			List<DecisionTreeNode> children = root.getChildren();
			while (children != null) {
				
				boolean matched = false;

				for (DecisionTreeNode node : children) {
					if (node.match(frames)) {
						children = node.getChildren();
						matched = true;
						break;
					}
				}
				
				if (!matched)
					break;
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
