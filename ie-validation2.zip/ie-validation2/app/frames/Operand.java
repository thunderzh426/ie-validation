package frames;

abstract public class Operand
{
	public enum OperandType {NUMBER, STRING, EXPRESSION};
	
	protected OperandType opType;
	protected Object value;
	
	abstract public boolean eval();
	
	public OperandType getType()
	{
		return opType;
	}
	
	public void setType(OperandType opType)
	{
		this.opType = opType;
	}
	
	public Object getValue()
	{
		return value;
	}
	
	public void setValue(Object value)
	{
		this.value = value;
	}
}
