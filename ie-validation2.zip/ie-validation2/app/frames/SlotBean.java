package frames;

public class SlotBean
{
	private String annotType;
	

	public SlotBean()
	{
	}
}
