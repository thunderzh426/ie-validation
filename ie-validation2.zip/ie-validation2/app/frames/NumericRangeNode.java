package frames;

import java.util.*;

public class NumericRangeNode extends DecisionTreeNode
{
	private double start;
	private double end;
	private int op1;
	private int op2;
	
	//ops:
	//0: undefined, 1: <, 2: <=, 3: ==, 4: >, 5: >= 
	
	public NumericRangeNode()
	{
	}
	
	public NumericRangeNode(String outputID, String className, double start, double end, int op1, int op2)
	{
		super(outputID, className);
		this.start = start;
		this.end = end;
		this.op1 = op1;
		this.op2 = op2;
	}
	
	public boolean match(Map<String, Frame> frames) throws DecisionTreeInvalidTypeException
	{
		
		/*
		
		if (!(value instanceof Number))
			throw new DecisionTreeInvalidTypeException();
		
		double number = ((Number) value).doubleValue();
		
		if (op1 == 4) {
			if (number <= start)
				return false;
		}
		else if (op1 == 5) {
			if (number < start)
				return false;
		}
		else if (op1 == 3)
			return number == start;
		
		if (op2 == 1) {
			if (number >= end)
				return false;
		}
		else if (op2 == 2) {
			if (number > end)
				return false;
		}
			
			*/
		return true;
	}
}
