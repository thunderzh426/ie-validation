package frames;

public class DecisionTreeInvalidTypeException extends Exception
{
}
