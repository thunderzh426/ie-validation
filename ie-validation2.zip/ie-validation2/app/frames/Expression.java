package frames;

public class Expression extends Operand
{
	public enum Operator {EQ, LT, LTE, GT, GTE, NOT, AND, OR};
	
	private Operand operand1;
	private Operand operand2;
	private Operator op;
	
	public Expression()
	{
	}
	
	public Expression(Operand operand1, Operand operand2, Operator op)
	{
		this.operand1 = operand1;
		this.operand2 = operand2;
		this.op = op;
	}
	
	public boolean eval()
	{
		boolean val1 = operand1.eval();
		boolean val2 = operand2.eval();
		
		boolean result = false;

		if (operand1.getType() == Operand.OperandType.NUMBER && operand2.getType() == Operand.OperandType.NUMBER) {
			switch (op)
			{
			case EQ:
				result = ((Number) operand1.getValue()).equals(((Number) operand2.getValue()));
			}
		}
		
		return result;
	}
}
