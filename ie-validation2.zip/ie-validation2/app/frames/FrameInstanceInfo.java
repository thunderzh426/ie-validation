package frames;

public class FrameInstanceInfo
{
}
