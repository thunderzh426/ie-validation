package frames;

public class AnnotationBean
{
	private String annotType;
	private int start;
	private int end;

	public AnnotationBean()
	{
	}
	
	public AnnotationBean(String annotType, int start, int end)
	{
		this.annotType = annotType;
		this.start = start;
		this.end = end;
	}

	public String getAnnotType() {
		return annotType;
	}

	public void setAnnotType(String annotType) {
		this.annotType = annotType;
	}

	public int getStart() {
		return start;
	}

	public void setStart(int start) {
		this.start = start;
	}

	public int getEnd() {
		return end;
	}

	public void setEnd(int end) {
		this.end = end;
	}
}
