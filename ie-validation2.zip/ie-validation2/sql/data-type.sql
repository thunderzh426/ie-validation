/*
-- Query: SELECT * FROM validator.data_type
-- Date: 2015-10-12 09:50
*/
INSERT INTO validator.data_type (name) VALUES ('number');
INSERT INTO validator.data_type (name) VALUES ('string');
INSERT INTO validator.data_type (name) VALUES ('date');
INSERT INTO validator.data_type (name) VALUES ('categorical');
