/*
-- Query: SELECT * FROM validator.element_type
-- Date: 2015-10-12 09:49
*/
INSERT INTO validator.element_type (element_type_name) VALUES ('text');
INSERT INTO validator.element_type (element_type_name) VALUES ('number');
INSERT INTO validator.element_type (element_type_name) VALUES ('radio');
INSERT INTO validator.element_type  element_type_name) VALUES ('checkbox');
INSERT INTO validator.element_type (element_type_name) VALUES ('date');
INSERT INTO validator.element_type (element_type_name) VALUES ('select');
INSERT INTO validator.element_type (element_type_name) VALUES ('textarea');
