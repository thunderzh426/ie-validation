
var elementIDMap = {};
var elementHTMLIDMap = {};
var gridData = new Array();
var gridData2 = new Array();
var frameInstanceData;
var highlightStart;
var highlightEnd;
var currFrameInstanceID;
var docNamespace;
var docTable;
var docID;
var docName;
var clickStart;
var clickEnd;
var clickValueElement;
var clickValue;
var valueClickCount1 = 0;
var valueClickCount2 = 0;
var origText = "";
var docHistory = {};
var currSelectedDoc;
var docIndexMap = {};
var frameArray;
var currFrameInstanceIndex;
var docFeatures;
var docFeatureKey;
var docFeatureValue = null;
var docFeatureID = null;

$(document).ready(function () {
//$(function() {
	//init widgets (dialog window, split pane, etc)
   $('#splitter').jqxSplitter({ width: '100%', height: '100%', panels: [{size: '40%'}, {size: '60%'}]});
   
   /*
   $('#splitter').on('resize', function (event) {
	   loadFrameInstance(currFrameInstanceID, false);
	   //getDocument('{"docNamespace":"' + docNamespace + '","docTable":"' + docTable + '","docID":' + docID + "}");
   })
   */
   
   $('#splitter2').jqxSplitter({ width: '100%', height: '100%', panels: [{size: '30%'}, {size: '70%'}]});
   
   
   //$('#crfPanel').jqxPanel({ width: '100%', height: '100%', autoUpdate: true, sizeMode: 'fixed'});
   $('#docPanel').jqxPanel({ width: '90%', height: '90%', autoUpdate: true, sizeMode : 'fixed'});
   
   $('#dialogLoadInstance').jqxWindow({  
	   width: 200,
	       height: 100, 
	       resizable: false,
	       //okButton: $('#okButton'),
	       //cancelButton: $('#cancelButton'),
	       isModal: true,
	       initContent: function() {
	   }
       });
   
   $('#dialogLoadInstance').jqxWindow('close');

   var docListBoxSource = [];
   $("#docListBox").jqxListBox({ selectedIndex: 0, source: docListBoxSource, width: '95%', height: '90%'});
   $('#docListBox').on('select', function(event) {
	   //docIndex = event.args.item.index;
	   //docHistory[event.args.item.value] = true;
	   var item = event.args.item;
	   getDocument(item.value, item.index);
	   //addDocumentHistory(event.args.item.value);
	   //$('#docListBox').val(event.args.item.value);
   });
   
   
   $('#docListBox').jqxListBox({renderer: function(index, label, value) {
			if (docHistory[value] == true) {
				return "<font style='background-color: powderblue'>" + label + "</font>";
			} 
			  
			return label;
		}
   });
   
   
   var data = new Array();
   data[0] = {element:"e1",value:"v1"};
   data[1] = {element:"e2",value:"v2"};
   
   gridSource =
   {
       localData: data,
       dataType: "array",
       dataFields: [
        {name: 'element', type: 'string'},
        {name: 'value', type: 'string'},
        {name: 'start', type: 'int'},
        {name: 'end', type: 'int'},
        {name: 'section', type: 'string'},
        {name: 'elementID', type: 'string'},
        {name: 'elementType', type: 'string'},
        {name: 'htmlID', type: 'string'},
        {name: 'elementHTMLID', type: 'string'},
        {name: 'elementValue', type: 'string'},
        {name: 'vScrollPos', type: 'int'},
        {name: 'scrollHeight', type: 'int'},
        {name: 'scrollWidth', type: 'int'},
        {name: 'valueHTMLID', type: 'string'},
        {name: 'annotFeatures', type: 'string'}
       ]
   };
   
   dataAdapter = new $.jqx.dataAdapter(gridSource, {
       loadComplete: function (data) { },
       loadError: function (xhr, status, error) { }      
   });
   
   $('#dataElementTable').jqxDataTable(
   {
	   height: '95%',
	   width: '95%',
	   theme: 'energyblue',
       source: dataAdapter,
       selectionmode: 'singlerow',
       enablehover: true,
       columns: [
         { text: 'Section', dataField: 'section', hidden: true },
         { text: 'Element', dataField: 'element', width: 400 },
         { text: 'Value', dataField: 'value', width: 400 }
       ],
       groups: ['section'],
       groupsRenderer: function(value, rowData, level)
       {
    	   //console.log(value);
    	   var sectionData = JSON.parse(value);
    	   //var sectionData = JSON.parse("{\"sectionID\":1}");
    	   //console.log(sectionData);
    	   var sectionName = sectionData["sectionName"];
    	   //console.log(sectionName);
    	   
    	   var index = sectionName.indexOf("|");
    	   var sectionNameShort = sectionName.substring(index+1);
    	   
    	   //var sectionHTML = sectionName;
    	   var repeat = sectionData["repeat"];
    	   var repeatIndex = sectionData["repeatIndex"];
    	   if (repeat > 0 || repeat == -1) {
	    	   if (repeatIndex == 1)
	    		   sectionName = sectionNameShort + "<br><input type='button' id='" + sectionNameShort + "' value='+' onclick='addSection(this.id)'/>";
	    	   else
	    		   sectionName = sectionNameShort + "<br><input type='button' id='" + sectionNameShort + "_" + repeatIndex + "' value='-' onclick='removeSection(this.id)'/>";
    	   }
    	   else
    		   sectionName = sectionNameShort;

           return sectionName;
       }
   });
   
   $('#dataElementTable').on('rowSelect', function (event) {
	   console.log(event.args.index);
	   //rowSelect(event.args.row);
	   rowSelect(event.args);
   });

   
   /*
   var source = new Array();
   source[0] = 'No Instances';
   $('#crfCombo').jqxComboBox({ source: source, selectedIndex: 0, width: '250', height: '20px'});
   $('#crfCombo').jqxComboBox({disabled:true});
   */
   
   
// Make sure the object is created if it's already not
   if(!window.CurrentSelection){
       CurrentSelection = {}
   }
   //define the selector object
   CurrentSelection.Selector = {}
   var div = document.getElementById("docPanel");
    
   //get the current selection
   CurrentSelection.Selector.getSelected = function(){
       var sel = '';
       if(window.getSelection){
           sel = window.getSelection()
       }
       else if(document.getSelection){
           sel = document.getSelection()
       }
       else if(document.selection){
           sel = document.selection.createRange()
       }
       return sel
   }
   
   /*
   //function to be called on mouseup
   CurrentSelection.Selector.mouseup = function() {
	   
       var st = CurrentSelection.Selector.getSelected()
       if(document.selection && !window.getSelection){
           var range = st
           //alert(range);
           //range.pasteHTML("<span class='selectedText'>" + range.htmlText + "</span>");
       }
       else{
           var range = st.getRangeAt(0);
           var div = document.getElementById('docPanel');
           var precedingRange = document.createRange();
           precedingRange.setStartBefore(div);
           precedingRange.setEnd(range.startContainer, range.startOffset);
           alert(precedingRange.toString().length);
	   }
   }
    
   $(function(){
       $(document.body).bind("mouseup",CurrentSelection.Selector.mouseup)
   })
   */
   
   document.getElementById('projSelect').selectedIndex = 0;
});


//$( window ).resize(function() {
$(window).on('resize', function(e) {
	  
	  window.resizeEvt;
	  $(window).resize(function() {
		  clearTimeout(window.resizeEvt);
		  window.resizeEvt = setTimeout(function() {
			  //code to do after window is resized
			  console.log("window resized!");
			  //loadFrameInstance(currFrameInstanceID, false);
			  loadFrameInstanceNoRT();
		  }, 250);
	  });
});


function loadDocument(docInfoStr)
{
}

function getDocument(docInfoStr, index)
{
	console.log("getDocument: " + docInfoStr);
	docHistory[docInfoStr] = true;
	//var docInfo = JSON.parse(docInfoStr);
	addDocumentHistory(docInfoStr);
	
	$('#docListBox').jqxListBox('refresh');
	$('#docListBox').jqxListBox('ensureVisible', index);
	$('#docListBox').jqxListBox('selectIndex', index);
	

	var docInfo = JSON.parse(docInfoStr);
	
	docNamespace = docInfo["docNamespace"];
	docTable = docInfo["docTable"];
	//docKey = docInfo["docKey"];
	//docTextColumn = docInfo["docTextColumn"];
	docID = docInfo["docID"];
	
	console.log(docNamespace + ", " + docTable + ", " + docID);
	
	//text = "";
	var getDocumentAjax = jsRoutes.controllers.Application.getDocument();
	$.ajax({
		type: "POST",
		url: getDocumentAjax.url,
		async: false,
		data:{docNamespace:docNamespace, docTable:docTable, docID:docID}
	}).done(function(data) {
		console.log(data);
		
		var docData = JSON.parse(data);
		
		docName = docData["docName"];
		origText = docData["docText"];
		var text = origText.split("\n").join("&nbsp;<br />");
		
		$('#docPanel').jqxPanel('clearcontent');
		$('#docPanel').jqxPanel('append', "<div style='margin:10px;'>" + text + "</div>");
		
		$('#docTitleDiv').text(docName);
		
		
		//set the document features
		var featuresHTML = "";
		docFeatures = JSON.parse(docData["docFeatures"]);
		for (var key in docFeatures) {
			var value = docFeatures[key];
			featuresHTML = featuresHTML.concat("<input id='" + key + "_docfeature' name='docfeature' type='radio' value='{\"key\":\"" + key + "\",\"value\":\"" + value + "\"}' onclick='docFeatureClicked(this.value, this.id)'><label class='unselectable'>" + key + ": " + value + "</label><br>");
		}
		
		$('#docFeatures').html(featuresHTML);


		//highlightText(rowStart, rowEnd, vScrollPos);

	}).fail(function() {
	});
	
	/*
	var getAnnotationsAjax = jsRoutes.controllers.Application.getAnnotations(docID);
	$.ajax({
			type: 'POST',
			url: getAnnotationsAjax.url,
			data:{docID: docID, annotTypeList: "['nodule-size','nodule-location']"}
		}).done(function(data) {
			console.log(data);
			
			annotList = JSON.parse(data);
			var i;
			var gridData = new Array();
			for (i=0; i<annotList.length; i++) {
				row = {};
				row["element"] = annotList[i]["annotationTypes"][0];
				start = annotList[i]["start"];
				end = annotList[i]["end"];
				features = JSON.parse(annotList[i]["features"]);
				row["value"] = features["Text"];
				row["start"] = start;
				row["end"] = end;
				gridData[i] = row;
			}
			
			console.log(JSON.stringify(gridData));
			
			gridSource.localData = gridData;
			dataAdapter = new $.jqx.dataAdapter(gridSource, {
			       loadComplete: function (data) { },
			       loadError: function (xhr, status, error) { }      
			   });
            $("#dataElementTable").jqxDataTable({ source: dataAdapter });
			
		}).fail(function() {
	});
	*/
}

function rowSelect(row)
{
	var index = row.index;
	var rowData = gridData2[index];
	var rowValue = rowData["elementValue"];

	
	var elementType = rowData['elementType'];
	
	
	
	//check if the user highlighted anything
	var start = 0;
	var end = 0;
	var value;
	var range = null;
	
	var st = CurrentSelection.Selector.getSelected();
    if (document.selection && !window.getSelection) {
        range = st
        //alert(range);
        //range.pasteHTML("<span class='selectedText'>" + range.htmlText + "</span>");
        
    }
    else {
    	if (st.rangeCount > 0) {
	        range = st.getRangeAt(0);
    	}
    }
    
	
	if (range != null) {
        var div = document.getElementById('docPanel');
        var precedingRange = document.createRange();
        precedingRange.setStartBefore(div);
        precedingRange.setEnd(range.startContainer, range.startOffset);
        value = range.toString();
        start = precedingRange.toString().length;
        end = (start + value.length);
        console.log("row select highlighted: " + start + "," + end);
        console.log(precedingRange.toString());
    }
	
	var rowStart = rowData["start"];
	var rowEnd = rowData["end"];
	var vScrollPos = rowData["vScrollPos"];
	var scrollHeight = rowData["scrollHeight"];
	var scrollWidth = rowData["scrollWidth"];
	
	if (vScrollPos == undefined) {
	    vScrollPos = Math.round($("#docPanel").jqxPanel('getVScrollPosition'));
	    scrollHeight = Math.round($("#docPanel").jqxPanel('getScrollHeight'));
	    scrollWidth = Math.round($("#docPanel").jqxPanel('getScrollWidth'));
	}
	
	console.log("rowStart: " + rowStart);
	console.log("rowEnd: " + rowEnd);
	console.log("element: " + rowData['element']);
	
	
	//if (start == end && docFeatureValue == null && rowValue != null && rowValue.length > 0) {
	if (start == end && docFeatureValue == null) {
		//clear any existing selections highlights for doc metadata
		$('[name=docfeature]').each(function() {
			var keyValue = JSON.parse($(this).val());
			$(this).prop('checked', false);
			$(this).next().html(keyValue["key"] + ": " + keyValue["value"]);
		});
				
		if (rowStart != undefined) {
		    console.log("rowselect: " + docNamespace + "," + docTable + "," + docID);
		    var docIndex = docIndexMap["{\"docNamespace\":\"" + rowData["docNamespace"] + "\",\"docTable\":\"" + rowData["docTable"] + "\",\"docID\":" + rowData["docID"] + "}"];
		    if (rowData["docNamespace"] != docNamespace || rowData["docTable"] != docTable || rowData["docID"] != docID) {
			    getDocument("{\"docNamespace\":\"" + rowData["docNamespace"] + "\",\"docTable\":\"" + rowData["docTable"] + "\",\"docID\":" + rowData["docID"] + "}", docIndex);
		    }
		    else {
			$('#docListBox').jqxListBox('refresh');
			$('#docListBox').jqxListBox('ensureVisible', docIndex);
			$('#docListBox').jqxListBox('selectIndex', docIndex);
		    }
		    
		    if (rowStart >= 0)
		    	highlightText(rowStart, rowEnd, vScrollPos, scrollHeight, scrollWidth);
		    else {
		    	//this is document metadata
		    	console.log(rowData["annotFeatures"]);
		    	var annotFeatures = JSON.parse(rowData["annotFeatures"]);
		    	console.log(annotFeatures);
		    	var id = annotFeatures["key"] + "_docfeature";
		    	$('#' + id).prop('checked', true);
		    	$('#' + id).next().html("<span class='highlight' style='background-color:lightgray'>" + annotFeatures["key"] + ": " + annotFeatures["value"] + "</span>");
		    	highlightText(0, -1, 0, 1, 1);
		    }
		    
		    console.log("index: " + docIndex);
		}
		else
		    highlightText(0, -1, 0, 1, 1);
	}
	
	if (elementType != 'text') {
		
		//callback for individual value element (e.g., radio button, checkbox, etc)
		clickStart = start;
		clickEnd = end;
		clickValue = value;
		valueClickCount1++;
		
		if (valueClickCount1 > 1) {
			valueClickCount1 = 1;
		}
		
		valueClickCallback();
	}

	var annotFeatures = null;
	//something was highlighted
	if (start != end || docFeatureValue != null) {
		
		if (docFeatureValue != null) {
			start = -1;
			end = -1;
			vScrollPos = 0;
			value = docFeatureValue;
			//$('#docfeature:checked').prop('checked', false);
			annotFeatures = '{"key":"' + docFeatureKey + '","value":"' + value + '"}';
			highlightText(0, -1, 0, 1, 1);
		}
		else {
			$('[name=docfeature]').each(function() {
				var keyValue = JSON.parse($(this).val());
				$(this).prop('checked', false);
				$(this).next().html(keyValue["key"] + ": " + keyValue["value"]);
			});
		}
		
		if (value != rowData['elementValue']) {
			//var elementType = rowData['elementType'];
			console.log("elementType: " + elementType);
	
			var htmlID = rowData['elementHTMLID'];
			var element = $(jq(htmlID))
			console.log(element.prop('id'));
			
			if (elementType != undefined && elementType == 'text') {
			    vScrollPos = Math.round($("#docPanel").jqxPanel('getVScrollPosition'));
			    scrollHeight = Math.round($("#docPanel").jqxPanel('getScrollHeight'));
			    scrollWidth = Math.round($("#docPanel").jqxPanel('getScrollWidth'));
				element.val(value);
				
				console.log("Add: " + docNamespace + "," + docTable + "," + docID);
			
				var addAnnotationAjax = jsRoutes.controllers.Application.addAnnotation();
				$.ajax({
						type: 'POST',
						url: addAnnotationAjax.url,
					    data:{htmlID:htmlID, value:value,start:start,end:end,docNamespace:docNamespace,docTable:docTable,docID:docID,vScrollPos:vScrollPos,
					    	scrollHeight:scrollHeight,scrollWidth:scrollWidth,features:annotFeatures}
					}).done(function(data) {
						console.log("highlight: start=" + start + " end=" + end + "scrollHeight=" + scrollHeight + " docFeatureValue = " + docFeatureValue);

						if (start >= 0)
							highlightText(start, end, vScrollPos, scrollHeight, scrollWidth);
						
						
						else if (docFeatureValue != null) {
							$('#docfeature:checked').each(function() {
								$(this).next().html("<span class='highlight' style='background-color:lightgray'>" + annotFeatures["key"] + ": " + annotFeatures["value"] + "</span>");
							});
						
							docFeatureValue = null;
						}

						var newRow = {};
						newRow["htmlID"] = htmlID;
						newRow["value"] = value;
						frameInstanceData.push(newRow);

					}).fail(function () {
				});
			}
			
			rowData['start'] = start;
			rowData['end'] = end;
			rowData['elementValue'] = value;
			rowData['valueHTMLID'] = htmlID;
			rowData['vScrollPos'] = Math.round($("#docPanel").jqxPanel('getVScrollPosition'));
			rowData['scrollHeight'] = Math.round($("#docPanel").jqxPanel('getScrollHeight'));
			rowData['scrollWidth'] = Math.round($("#docPanel").jqxPanel('getScrollWidth'));
			rowData['docNamespace'] = docNamespace;
			rowData['docTable'] = docTable;
			rowData['docID'] = docID;
			rowData['annotFeatures'] = annotFeatures;
			
			if (docFeatureValue == null)
				highlightText(start, end, $("#docPanel").jqxPanel('getVScrollPosition'), $("#docPanel").jqxPanel('getScrollHeight'), $("#docPanel").jqxPanel('getScrollWidth'));
			//docFeatureValue = null;
		}
	}
	
	/*
	if (window.getSelection) {
	  if (window.getSelection().empty) {  // Chrome
	    window.getSelection().empty();
	  }
	  else if (window.getSelection().removeAllRanges) {  // Firefox
	    window.getSelection().removeAllRanges();
	  }
	}
	else if (document.selection) {  // IE?
		document.selection.empty();
	}
	*/
	
}

function highlightText(start, end, vScrollPos, scrollHeight, scrollWidth)
{
	if (origText == null || origText.length == 0)
		return;
		
	highlightStart = start;
	highlightEnd = end;
	var text = origText;
	var origVPos = $("#docPanel").jqxPanel('getVScrollPosition');
	var flag = false;
	if (start < end) {
		text = origText.substring(0, start) + "<span class='highlight' style='background-color:lightgray'>" + origText.substring(start, end) + "</span>" + origText.substring(end);
		flag = true;
	}
	text = text.split("\n").join("&nbsp;<br/>");
	//console.log(text);
	$("#docPanel").jqxPanel('clearcontent');
	$("#docPanel").jqxPanel('append', '<div style="margin: 50px">' + text + '</div>');
	//$("#docPanel").jqxPanel('append', text);
	//$("#docPanel").jqxPanel('append', "</div>");
	
	var caretPos = origVPos;
	if (flag) {
	    console.log("vscrollpos = " + vScrollPos + " scrollHeight = " + scrollHeight);
	    //caretPos = vScrollPos;
	    var currScrollWidth = Math.round($("#docPanel").jqxPanel('getScrollWidth'));
	    var currScrollHeight = Math.round($("#docPanel").jqxPanel('getScrollHeight'));
		var factor = vScrollPos / scrollHeight;
		console.log("currScrollHeight = " + currScrollHeight + " factor = " + factor);

		caretPos = Math.round(currScrollHeight * factor);
	}

	$('#docPanel').jqxPanel('scrollTo', 0, caretPos);
	
	
	$('#docPanel').jqxPanel('append', '');
}

function countLines(text, endIndex)
{
	var count = 0;
	var index = text.indexOf("&nbsp;");
	while (index >= 0 && index < endIndex) {
		count++;
		index = text.indexOf("&nbsp;", index+6);
	}
	
	return count;
}

function setCaretPosition(elemId, caretPos) {
    var el = document.getElementById(elemId);

    el.value = el.value;
    // ^ this is used to not only get "focus", but
    // to make sure we don't have it everything -selected-
    // (it causes an issue in chrome, and having it doesn't hurt any other browser)
    
    
    if (el !== null) {

        if (el.createTextRange) {
            var range = el.createTextRange();
            range.move('character', caretPos);
            range.select();
            return true;
        }

        else {
            // (el.selectionStart === 0 added for Firefox bug)
            if (el.selectionStart || el.selectionStart === 0) {
                el.focus();
                el.setSelectionRange(caretPos, caretPos);
                el.blur();

                return true;
            }

            else  { // fail city, fortunately this never happens (as far as I've tested) :)
                el.focus();
                return false;
            }
        }
    }
}

function loadCRF(crfName)
{
	var getCRFAjax = jsRoutes.controllers.Application.getCRF(crfName);
	$.ajax({
		type: 'GET',
		url: getCRFAjax.url,
	}).done(function(data) {
		//console.log(data);
		
		loadCRFData(data);
	})
}

function loadProject(projName)
{
	var loadProjectAjax = jsRoutes.controllers.Application.loadProject(projName);
	$.ajax({
		type: 'GET',
		url: loadProjectAjax.url,
	}).done(function(data) {
		console.log(data);
		
		var result = JSON.parse(data);
		frameArray = result[0];
		var lastFrameAccessed = result[1];
		var crfData = result[2];
		var optionsStr = "<option selected disabled value=''>Select Instance</option>";
		for(var i = 0; i < frameArray.length; i++) {
		    optionsStr += "<option value='" + frameArray[i]["frameInstanceID"] + "'>" + frameArray[i]["name"] + "</option>";
		}
		
		$("#crfSelect").find('option').remove().end().append($(optionsStr));
		document.getElementById('crfSelect').selectedIndex = 0;
		
		loadCRFData(crfData);
		
		
		currFrameInstanceIndex = lastFrameAccessed["lastFrameInstanceIndex"];
		var frameInstanceID = lastFrameAccessed["lastFrameInstanceID"];
		
		console.log("frameInstanceID: " + frameInstanceID);
		
		loadFrameInstance(frameInstanceID, true);
		$('#crfSelect').prop('selectedIndex', currFrameInstanceIndex);
	})
}

function frameInstanceSelected(frameInstanceID, clearDoc, frameInstanceIndex)
{
	currFrameInstanceIndex = frameInstanceIndex;
	loadFrameInstance(frameInstanceID, clearDoc);
}

function loadFrameInstance(frameInstanceID, clearDoc)
{
	console.log(frameInstanceID);

	$('#dialogLoadInstance').jqxWindow('open');
	
	currFrameInstanceID = frameInstanceID;
	

	var loadFrameInstanceAjax = jsRoutes.controllers.Application.loadFrameInstance(frameInstanceID);
	$.ajax({
		type: 'GET',
		url: loadFrameInstanceAjax.url,
	}).done(function(data) {
		console.log(data);
		
		var dataObj = JSON.parse(data);
		
		var crfData = dataObj[2];
		loadCRFData(crfData);

		
		frameInstanceData = dataObj[0];
		for (var i=0; i<frameInstanceData.length; i++) {
			//var value = frameInstanceData[i]["value"];
			var elementID = frameInstanceData[i]["elementID"];
			//var htmlID = frameInstanceData[i]["htmlID"];
			var start = frameInstanceData[i]["start"];
			var end = frameInstanceData[i]["end"];
			var docNamespace = frameInstanceData[i]["docNamespace"];
			var docTable = frameInstanceData[i]["docTable"];
			var docID = frameInstanceData[i]["docID"];
			var vScrollPos = frameInstanceData[i]["vScrollPos"];
			var scrollHeight = frameInstanceData[i]["scrollHeight"];
			var scrollWidth = frameInstanceData[i]["scrollWidth"];
			var annotFeatures = frameInstanceData[i]["features"];
			
			var elementIndex = elementIDMap[elementID];
			console.log("elementID: " + elementID);
			gridData[elementIndex]["start"] = start;
			gridData[elementIndex]["end"] = end;
			gridData[elementIndex]["elementValue"] = value;
			gridData[elementIndex]["docNamespace"] = docNamespace;
			gridData[elementIndex]["docTable"] = docTable;
			gridData[elementIndex]["docID"] = docID;
			gridData[elementIndex]["vScrollPos"] = vScrollPos;
			gridData[elementIndex]["scrollHeight"] = scrollHeight;
			gridData[elementIndex]["scrollWidth"] = scrollWidth;
			gridData[elementIndex]["annotFeatures"] = annotFeatures;
			
			
			/*
			var element = $("#" + htmlID);
			console.log(element.prop('tagName') + "," + element.attr('type'));
			if (element.prop('tagName').toLowerCase() == "input") {
				var elType = element.attr('type').toLowerCase();
				if (elType == "text") {
					element.val(value);
				}
				else if (elType == "checkbox" || elType == "radio") {
					element.prop('selected', true);
				}
			}
			*/
		}
		
		//reload grid data into table
		gridSource.localData = gridData;
		dataAdapter = new $.jqx.dataAdapter(gridSource, {
		       loadComplete: function (data) { },
		       loadError: function (xhr, status, error) { }      
		   });
	    $("#dataElementTable").jqxDataTable({ source: dataAdapter });
	    
	    //set HTML elements
	    for (var i=0; i<frameInstanceData.length; i++) {
	    	var htmlID = frameInstanceData[i]["htmlID"];
	    	var value = frameInstanceData[i]["value"];
	    	
	    	console.log("htmlID: " + jq(htmlID));
	    	var element = $(jq(htmlID));
	    	
			console.log(element.prop('tagName') + "," + element.attr('type'));
			if (element.prop('tagName').toLowerCase() == "input") {
				var elType = element.attr('type').toLowerCase();
				if (elType == "text") {
					element.val(value);
				}
				else if (elType == "checkbox" || elType == "radio") {
					element.prop('checked', true);
				}
			}
	    }
	    
		
	    //load doc text
	    /*
		origText = dataObj[1];
		var text = origText.split("\n").join("&nbsp;<br />");
		//var text = origText;
		//quill.setText(text);
		
		$('#docPanel').jqxPanel('clearcontent');
		$('#docPanel').jqxPanel('append', text);
		*/
		
		
		if (clearDoc) {
			//set document panel title
			$("#docTitleDiv").text("No Document Selected");
			
			//clear document panel
			$('#docPanel').jqxPanel('clearcontent');
			
			//remove doc metadata
			$('#docFeatures').html("");
		}
		
		//load document list
		
		var docList = dataObj[3];
		
		/*
		optionsStr = "<option selected disabled value=''>Select Report</option>";
		for (var i = 0; i < docList.length; i++) {
		    optionsStr += "<option value='{\"docNamespace\":\"" + docList[i]["docNamespace"] + "\",\"docTable\":\"" + docList[i]["docTable"] 
		    + "\",\"docID\":" + docList[i]["docID"] + "}'>" + docList[i]["docName"] + "</option>";
		}
		
		$("#docSelect").find('option').remove().end().append($(optionsStr));
		document.getElementById('docSelect').selectedIndex = 0;
		*/


		//load document list into listbox
		var docListBoxSource = [];
		for (var i = 0; i < docList.length; i++) {
			var oneDoc = {};
			oneDoc["label"] = docList[i]["docName"];
			oneDoc["value"] = "{\"docNamespace\":\"" + docList[i]["docNamespace"] + "\",\"docTable\":\"" + docList[i]["docTable"] 
		    	+ "\",\"docID\":" + docList[i]["docID"] + "}";
			docIndexMap["{\"docNamespace\":\"" + docList[i]["docNamespace"] + "\",\"docTable\":\"" + docList[i]["docTable"] 
		    	+ "\",\"docID\":" + docList[i]["docID"] + "}"] = i;
			
			docListBoxSource.push(oneDoc);
		}

		getDocumentHistory();
		
		$("#docListBox").jqxListBox({source: docListBoxSource});
		$('#docListBox').jqxListBox('refresh');

		$('#dialogLoadInstance').jqxWindow('close');
	})
}

function loadFrameInstanceNoRT()
{
	if (frameInstanceData == null)
		return;
		
    //set HTML elements
    for (var i=0; i<frameInstanceData.length; i++) {
    	var htmlID = frameInstanceData[i]["htmlID"];
    	var value = frameInstanceData[i]["value"];
    	
    	console.log("htmlID: " + jq(htmlID));
    	var element = $(jq(htmlID));
    	
		console.log(element.prop('tagName') + "," + element.attr('type'));
		if (element.prop('tagName').toLowerCase() == "input") {
			var elType = element.attr('type').toLowerCase();
			if (elType == "text") {
				element.val(value);
			}
			else if (elType == "checkbox" || elType == "radio") {
				element.prop('checked', true);
			}
		}
    }		
}

function addSection(sectionName)
{
	var addSectionAjax = jsRoutes.controllers.Application.addSection(sectionName);
	$.ajax({
		type: 'GET',
		url: addSectionAjax.url,
	}).done(function(data) {
		console.log(data);
		if (data.length > 0) {
			loadCRFData(JSON.parse(data));
			loadFrameInstance(currFrameInstanceID, false);
		}
	})
}

function removeSection(sectionName)
{
	var index = sectionName.lastIndexOf("_");
	var repeatIndex = parseInt(sectionName.substring(index+1));
	sectionName = sectionName.substring(0, index);
	
	var removeSectionAjax = jsRoutes.controllers.Application.removeSection(sectionName, repeatIndex);
	$.ajax({
		type: 'GET',
		url: removeSectionAjax.url,
	}).done(function(data) {
		console.log(data);
		if (data.length > 0) {
			loadCRFData(JSON.parse(data));
			loadFrameInstance(currFrameInstanceID, false);
		}
	})
}

function addElement(id)
{
	index = id.lastIndexOf("_");
	id = id.substring(0, index);
	
	console.log("add element: " + id);
	var addElementAjax = jsRoutes.controllers.Application.addElement(id);
	$.ajax({
		type: 'GET',
		url: addElementAjax.url,
	}).done(function(data) {
		console.log(data);
		if (data.length > 0) {
			loadCRFData(JSON.parse(data));
			loadFrameInstance(currFrameInstanceID, false);
		}
	})
}

function removeElement(id)
{
	index = id.lastIndexOf("_");
	id = id.substring(0, index);
	
	console.log("remove element: " + id);
	var removeElementAjax = jsRoutes.controllers.Application.removeElement(id);
	$.ajax({
		type: 'GET',
		url: removeElementAjax.url,
	}).done(function(data) {
		console.log(data);
		if (data.length > 0) {
			loadCRFData(JSON.parse(data));
			loadFrameInstance(currFrameInstanceID, false);
		}
	})
}

function loadCRFData(elementList)
{
	//var elementList = JSON.parse(data);
	
	gridData = new Array();
	
	var i;
	for (i=0; i<elementList.length; i++) {
		var row = {};
		element = elementList[i];
		row["section"] = element["section"];
		row["element"] = "<label class='unselectable'><b>" + element["display"] + "</b></label>";
		row["value"] = element["html"];
		row["elementID"] = element["elementID"];
		row["elementHTMLID"] = element["htmlID"];
		row["elementType"] = element["elementType"];
		
		elementIDMap[element["elementID"]] = i;
		elementHTMLIDMap[element["htmlID"]] = i;
		
		gridData[i] = row;
		gridData2[i] = row;
		console.log(row["elementID"] + ", " + row["element"]);
	}
	
	gridSource.localData = gridData;
	dataAdapter = new $.jqx.dataAdapter(gridSource, {
	       loadComplete: function (data) { },
	       loadError: function (xhr, status, error) { }      
	   });
    $("#dataElementTable").jqxDataTable({ source: dataAdapter });
}

function clearElement()
{
	var selection = $("#dataElementTable").jqxDataTable('getSelection');
	if (selection != undefined) {
		var elementID = selection[0]["elementID"];
		var elementHTMLID = selection[0]["elementHTMLID"];
		var elementType = selection[0]["elementType"];
		var elementIndex = elementIDMap[elementID];
		gridData2[elementIndex]["start"] = 0;
		gridData2[elementIndex]["end"] = -1;
		
		console.log("clear: " +  elementID);
		console.log("clear: " +  elementHTMLID);
		
		var clearElementAjax = jsRoutes.controllers.Application.clearElement(elementHTMLID);
		$.ajax({
			type: 'GET',
			url: clearElementAjax.url,
		}).done(function(data) {
		})
		
		var element = $(jq(elementHTMLID));
		if (elementType == "text")
			element.val('');
		else {
			$('input[name="' + elementHTMLID + '"]').prop('checked',false);
		}
		
		highlightText(0, -1, 0, 1, 1);
	}
}

function clearAll()
{
	var clearAllAjax = jsRoutes.controllers.Application.clearAll();
	$.ajax({
		type: 'GET',
		url: clearAllAjax.url,
		async: false
	}).done(function(data) {
	})
	
	    highlightText(0, -1, 0, 1, 1);
	loadFrameInstance(currFrameInstanceID, true);
}

function valueClick(valueElement)
{
	console.log(valueElement);
	clickValueElement = valueElement;
	
	valueClickCount2++;
	valueClickCallback();
}

function valueClickCallback()
{
	console.log("value click count = " + valueClickCount1 + ", " + valueClickCount2);
	
	if (valueClickCount1 > 1)
		valueClickCount1 = 0;
	
	if (valueClickCount1 != 1 || valueClickCount2 != 1)
		return;
	
	valueClickCount1 = 0;
	valueClickCount2 = 0;
	var start = clickStart;
	var end = clickEnd;
	
	console.log("value click highlighted: " + start + "," + end);
    //console.log(precedingRange.toString());
	
	if (start >= end) {
		start = highlightStart;
		end = highlightEnd;
	}
	
	if (start >= end)		
		return;
	
	
	var htmlID = clickValueElement.id;
	console.log(htmlID);
	
	var vScrollPos = Math.round($("#docPanel").jqxPanel('getVScrollPosition'));
	var scrollHeight = Math.round($("#docPanel").jqxPanel('getScrollHeight'));
	var scrollWidth = Math.round($("#docPanel").jqxPanel('getScrollWidth'));
	var addAnnotationAjax = sRoutes.controllers.Application.addAnnotation();
	$.ajax({
			type: 'POST',
			url: addAnnotationAjax.url,
		    data:{htmlID:htmlID, value:clickValue,start:start,end:end,docNamespace:docNamespace,docTable:docTable,docID:docID,vScrollPos:vScrollPos,scrollHeight:scrollHeight,scrollWidth:scrollWidth}
		}).done(function(data) {
			highlightText(start, end, vScrollPos, scrollHeight, scrollWidth);
			var newRow = {};
			newRow["htmlID"] = htmlID;
			newRow["value"] = clickValue;
			frameInstanceData.push(newRow);
		}).fail(function () {
	});
	
	var elementIndex = elementHTMLIDMap[clickValueElement.name];
	var rowData = gridData2[elementIndex];
	
	rowData['start'] = start;
	rowData['end'] = end;
	rowData['elementValue'] = clickValue;
	rowData['vScrollPos'] = vScrollPos;
	rowData['scrollHeight'] = scrollHeight;
	rowData['scrollWidth'] = scrollWidth;
	rowData['valueHTMLID'] = htmlID;
	rowData["docNamespace"] = docNamespace;
	rowData["docTable"] = docTable;
	rowData["docID"] = docID;
	highlightText(start, end, $("#docPanel").jqxPanel('getVScrollPosition'), $("#docPanel").jqxPanel('getScrollHeight'), $("#docPanel").jqxPanel('getScrollWidth'));
	console.log("element htmlID: " + clickValueElement.name);
	console.log("rowData: " + start + "," + end);
	
	
	/*
	gridSource.localData = gridData;
	
	dataAdapter = new $.jqx.dataAdapter(gridSource, {
	       loadComplete: function (data) { },
	       loadError: function (xhr, status, error) { }      
	   });
    $("#dataElementTable").jqxDataTable({ source: dataAdapter });
    
  //set HTML elements
    for (var i=0; i<gridData.length; i++) {
    	var htmlID = gridData[i]["valueHTMLID"];
    	if (htmlID == undefined)
    		htmlID = gridData[i]["elementHTMLID"];
    	var value = gridData[i]["elementValue"];
    	var element = $("#" + htmlID);
		console.log(element.prop('tagName') + "," + element.attr('type'));
		if (element.prop('tagName').toLowerCase() == "input") {
			var elType = element.attr('type').toLowerCase();
			if (elType == "text") {
				element.val(value);
			}
			else if (elType == "checkbox" || elType == "radio") {
				element.prop('checked', true);
			}
		}
    }
    */
	
	if (window.getSelection) {
	  if (window.getSelection().empty) {  // Chrome
	    window.getSelection().empty();
	  }
	  else if (window.getSelection().removeAllRanges) {  // Firefox
	    window.getSelection().removeAllRanges();
	  }
	}
	else if (document.selection) {  // IE?
		document.selection.empty();
	}
}

function addDocumentHistory(docInfoStr)
{
	var docInfo = JSON.parse(docInfoStr);
	var addDocHistAjax = jsRoutes.controllers.Application.addDocumentHistory();
	$.ajax({
			type: 'POST',
			url: addDocHistAjax.url,
			data:{docNamespace:docInfo["docNamespace"],
				docTable:docInfo["docTable"],docID:docInfo["docID"]}
		}).done(function(data) {
			
		}).fail(function () {
	});
}

function getDocumentHistory()
{
	var getDocHistAjax = jsRoutes.controllers.Application.getDocumentHistory();
	$.ajax({
			type: 'GET',
			url: getDocHistAjax.url
		}).done(function(data) {
			console.log("doc hist: " + data);
			docHistory = JSON.parse(data);
			for (var key in docHistory) {
			    var keyStr = JSON.stringify(key);
			    key["index"] = docIndexMap[keyStr];
			}
			$('#docListBox').jqxListBox('refresh');
		}).fail(function () {
	});
}

function clearDocumentHistory()
{
	var clearDocHistAjax = jsRoutes.controllers.Application.clearDocumentHistory();
	$.ajax({
			type: 'GET',
			url: clearDocHistAjax.url
		}).done(function(data) {
			docHistory = {};
			$('#docListBox').jqxListBox('clearSelection');
			$('#docListBox').jqxListBox('refresh');
		}).fail(function () {
	});
}

function jq( myid ) { 
    return "#" + myid.replace(/(\(|\)|\/|:|\.|\[|\]|,|\<|\>|\=)/g, "\\$1");
}

function prevInstance()
{
	if (currFrameInstanceIndex > 1) {
		currFrameInstanceIndex--;
		var frameInstanceID = frameArray[currFrameInstanceIndex-1]["frameInstanceID"];
		$('#crfSelect').prop('selectedIndex', currFrameInstanceIndex);
		loadFrameInstance(frameInstanceID, true)
	}
}

function nextInstance()
{
	if (currFrameInstanceIndex < frameArray.length) {
		currFrameInstanceIndex++;
		var frameInstanceID = frameArray[currFrameInstanceIndex-1]["frameInstanceID"];
		$('#crfSelect').prop('selectedIndex', currFrameInstanceIndex);
		loadFrameInstance(frameInstanceID, true)
	}
}

function docFeatureClicked(value, id)
{
	console.log("feature clicked! " + value + " id: " + id);
	console.log($('#' + id).next().text());
	
	$('[name=docfeature]').each(function() {
		var keyValue = JSON.parse($(this).val());
		$(this).next().html(keyValue["key"] + ": " + keyValue["value"]);
	});
	
	var keyValue = JSON.parse(value);
	$('#' + id).next().html("<span class='highlight' style='background-color:lightgray'>" + keyValue["key"] + ": " + keyValue["value"] + "</span>");
	docFeatureKey = keyValue["key"];
	docFeatureValue = keyValue["value"];
	docFeatureID = id;
}